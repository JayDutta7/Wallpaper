package app.matrix.wallpaperpexels.localdatabase.pojo

data class UserDetailsData(val id:Int=-1,val name:String,val email:String,val password:String,val phonenumber:String)