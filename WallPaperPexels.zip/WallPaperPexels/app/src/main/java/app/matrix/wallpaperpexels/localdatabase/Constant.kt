package app.matrix.wallpaperpexels.localdatabase

class Constant{
    companion object {
        //Application class name
        const val application:String="WallPaperPexels"
        //ApiKey
        const val apiKey:String="563492ad6f91700001000001dc458bd0c69244b7838514cd61678dca"
        //baseUrl
        val baseUrl:String="https://api.pexels.com/v1/"




        /* Shared prefrence key's*/
        val UserId:String="UserID"


    }
}