package app.matrix.wallpaperpexels.network.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class WebResponse(
    @SerializedName("photos")
    val photos: ArrayList<Response.Photos>?,
    @SerializedName("page")
    @Expose
    var page: Int?,
    @SerializedName("next_page")
    @Expose
    var next_page: String?,
    @SerializedName("per_page")
    @Expose
    var per_page: Int?

    /*var demoInner:Response.Nested*/


)