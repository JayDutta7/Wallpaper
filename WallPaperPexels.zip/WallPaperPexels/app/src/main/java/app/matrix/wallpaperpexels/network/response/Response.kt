package app.matrix.wallpaperpexels.network.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Awesome Pojo Generator
 */
 class Response {

    /*inner class Nested {
        fun innerClassSample() = "Inner Class Sample"
    }*/

    data class Photos(
        @SerializedName("src")
        @Expose
        var src: Src?,
        @SerializedName("width")
        @Expose
        var width: Int?,
        @SerializedName("photographer")
        @Expose
        var photographer: String?,
        @SerializedName("photographer_url")
        @Expose
        var photographer_url: String?,
        @SerializedName("id")
        @Expose
        var id: Int?,
        @SerializedName("url")
        @Expose
        var url: String?,
        @SerializedName("height")
        @Expose
        var height: Int?
    )

    data class Src(
        @SerializedName("small")
        @Expose
        var small: String?,
        @SerializedName("square")
        @Expose
        var square: String?,
        @SerializedName("original")
        @Expose
        var original: String?,
        @SerializedName("large")
        @Expose
        var large: String?,
        @SerializedName("tiny")
        @Expose
        var tiny: String?,
        @SerializedName("medium")
        @Expose
        var medium: String?,
        @SerializedName("large2x")
        @Expose
        var large2x: String?,
        @SerializedName("portrait")
        @Expose
        var portrait: String?,
        @SerializedName("landscape")
        @Expose
        var landscape: String?
    )

}