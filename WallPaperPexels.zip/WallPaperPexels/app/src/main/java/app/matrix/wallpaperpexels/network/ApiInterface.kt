package app.matrix.wallpaperpexels.network

import app.matrix.wallpaperpexels.network.response.WebResponse
import app.matrix.wallpaperpexels.localdatabase.Constant
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Headers


interface ApiInterface {

    @GET("curated?per_page=15&page=1")
    @Headers(
        "Authorization:" + Constant.apiKey,
        "Content-type:application/json"
    )
    fun getDetails(): Call<WebResponse>


    companion object {
        fun CreateRetroFitService(): ApiInterface {

            val retrofit = Retrofit.Builder()

                .baseUrl(Constant.baseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            return retrofit.create(ApiInterface::class.java)
        }

    }

}