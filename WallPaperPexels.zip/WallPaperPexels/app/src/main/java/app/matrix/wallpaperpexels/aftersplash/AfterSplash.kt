package app.matrix.wallpaperpexels.aftersplash

import android.net.ConnectivityManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import app.matrix.wallpaperpexels.R

class AfterSplash : AppCompatActivity() {


    companion object {
        private val TAG: String = AfterSplash::class.java.simpleName
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_aftersplash)



    }


}
