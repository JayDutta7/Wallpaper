package app.matrix.wallpaperpexels.login

import android.app.Dialog
import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.Window
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.widget.NestedScrollView
import app.matrix.wallpaperpexels.R
import app.matrix.wallpaperpexels.localdatabase.DatabaseHelper
import app.matrix.wallpaperpexels.localdatabase.pojo.UserDetailsData
import app.matrix.wallpaperpexels.registration.RegistrationActivity
import app.matrix.wallpaperpexels.utility.InputValidation
import butterknife.BindView
import butterknife.ButterKnife
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.android.synthetic.main.forgot_password.*
import java.security.AccessController.getContext

class LoginActivity : AppCompatActivity(), View.OnClickListener {


    @BindView(R.id.textInputEditTextEmail)
    lateinit var emailEditText: TextInputEditText

    @BindView(R.id.textInputLayoutEmail)
    lateinit var textInputLayoutEmail: TextInputLayout

    @BindView(R.id.textInputLayoutPassword)
    lateinit var textInputLayoutPassword: TextInputLayout

    @BindView(R.id.textInputEditTextPassword)
    lateinit var passEditText: TextInputEditText

    @BindView(R.id.appCompatButtonLogin)
    lateinit var loginButton: AppCompatButton

    @BindView(R.id.textViewLinkRegister)
    lateinit var textViewClick: AppCompatTextView

    @BindView(R.id.nestedScrollView)
    lateinit var nestedScrollView: NestedScrollView

    @BindView(R.id.textViewForgotPassword)
    lateinit var textViewForgotPassword:AppCompatTextView

    private lateinit var inputValidation: InputValidation
    private lateinit var databaseHelper: DatabaseHelper

    private lateinit var listUsers: MutableList<UserDetailsData>

    private val TAG=LoginActivity::class.java.name


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)


        initiaLizeID()

        var getDataFromSQLite = GetDataFromSQLite()
        getDataFromSQLite.execute()

    }


    inner class GetDataFromSQLite : AsyncTask<Void, Void, List<UserDetailsData>>() {

        override fun doInBackground(vararg p0: Void?): List<UserDetailsData> {
            return databaseHelper.getAllUser()
        }

        override fun onPostExecute(result: List<UserDetailsData>?) {
            super.onPostExecute(result)
            Log.e(TAG,""+result?.size)
            listUsers.clear()
            listUsers.addAll(result!!)
        }

    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.textViewLinkRegister -> clickToRegistrationPage()

            R.id.appCompatButtonLogin ->funLogin()

        }
    }

    private fun initiaLizeID() {
        ButterKnife.bind(this)

        //Initialization new class
        initObjects()

        //Initialize onClick
        loginButton.setOnClickListener(this)
        textViewClick.setOnClickListener(this)
        textViewForgotPassword.setOnClickListener(this)

    }

    private fun initObjects() {
        inputValidation = InputValidation(this@LoginActivity)
        databaseHelper = DatabaseHelper(this@LoginActivity)
        listUsers = ArrayList()

    }

    private fun clickToRegistrationPage() {

        val mainIntent = Intent(this@LoginActivity, RegistrationActivity::class.java)
        startActivity(mainIntent)

    }

    private fun funLogin() {

        if (!inputValidation.isInputEditTextFilled(
                emailEditText,
                textInputLayoutEmail,
                getString(R.string.error_message_email)
            )
        ) {
            return
        } else if (!inputValidation.isInputEditTextEmail(
                emailEditText,
                textInputLayoutEmail,
                getString(R.string.error_valid_email_password)
            )
        ) {
            return
        } else if (!inputValidation.isInputEditTextFilled(
                passEditText,
                textInputLayoutPassword,
                getString(R.string.error_message_password)
            )
        ) {
            return
        } else {

            if (databaseHelper.checkUserExits(
                    emailEditText.text.toString().trim { it <= ' ' },
                    passEditText.text.toString().trim { it <= ' ' })
            ) {
                Snackbar.make(nestedScrollView, getString(R.string.success_Loginmessage), Snackbar.LENGTH_SHORT).show()

                /*val mainIntent = Intent(this@LoginActivity, HomeActivity::class.java)
                startActivity(mainIntent)
                finish()*/

            } else {

                Snackbar.make(nestedScrollView, getString(R.string.user_notexits), Snackbar.LENGTH_SHORT).show()
            }


        }

    }




}
